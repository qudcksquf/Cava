package main;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.UnsupportedAudioFileException;

public class Music {
	private static Clip bgm = null;
	private static Clip driveSE = null;
	private static PlaySE[] ps = new PlaySE[7];
	
	public static void init() {
		for(int i=0;i<7;i++) ps[i] = new PlaySE();
	}
	
	public static void offBGM() {
		if(bgm != null) {
			bgm.stop();
			bgm = null;
		}
	}
	public static void changeBGM(String fileName) {
		if(bgm != null) {
			bgm.stop();
			bgm = null;
		}
		try {
			AudioInputStream ais = AudioSystem.getAudioInputStream(new BufferedInputStream(new FileInputStream(fileName)));
			bgm = AudioSystem.getClip();
			bgm.open(ais);
			bgm.start();
			bgm.loop(-1);
		}
		catch(Exception e4) {
			e4.printStackTrace();
		}
	}
	public static void drive(boolean running) {
		if(running == false) {
			if(driveSE != null) {
				driveSE.stop();
				driveSE = null;
			}
		}
		else if(driveSE == null) {
			try {
				AudioInputStream ais = AudioSystem.getAudioInputStream(new BufferedInputStream(new FileInputStream("engine_sound.wav")));
				driveSE = AudioSystem.getClip();
				driveSE.open(ais);
				driveSE.start();
				driveSE.loop(-1);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
	}
	public static void boost() {
		ps[0].playSound("booster_sound.wav");
	}
	public static void kit() {
		ps[1].playSound("kit_sound.wav");
	}
	public static void oil() {
		ps[2].playSound("oil_sound.wav");
	}
	public static void getItem() {
		ps[3].playSound("get_item_sound.wav");
	}
	public static void monster() {
		ps[4].playSound("monster_sound.wav");
	}
	public static void carcenterZero() {
		ps[5].playSound("carcenter0_sound.wav");
	}
	public static void carcenterOne() {
		ps[6].playSound("carcenter1_sound.wav");
	}
}
