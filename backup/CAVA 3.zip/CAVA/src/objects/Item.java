package objects;

public class Item extends Things {
	
	@Override
	void Touched() {
		// TODO Auto-generated method stub
		
	}

}
