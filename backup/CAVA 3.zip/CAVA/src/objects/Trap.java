package objects;

public class Trap extends Things{

	@Override
	void Touched() {
		// TODO Auto-generated method stub
		
	}
	
}
