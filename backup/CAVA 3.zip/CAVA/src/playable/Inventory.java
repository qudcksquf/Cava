package playable;

import javax.swing.JPanel;

public class Inventory extends JPanel{

}
