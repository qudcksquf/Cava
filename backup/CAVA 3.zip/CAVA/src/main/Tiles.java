package main;

import java.io.Serializable;

public class Tiles implements Serializable {

	private int mapOne_1[][];
	
	private int mapOne_2[][];
	
	private int mapOne_3[][];
	
	private int mapOne_4[][];
	
	private int mapOne_5[][];
	
	private int mapTwo_1[][];
	
	private int mapTwo_2[][];
	
	private int mapTwo_3[][];
	
	private int mapTwo_4[][];
	
	private int mapTwo_5[][];
	
	private int mapThree_1[][];
	
	private int mapThree_2[][];
	
	private int mapThree_3[][];
	
	private int mapThree_4[][];
	
	private int mapThree_5[][];
	

	public int[][] getMapOne_1() {
		return mapOne_1;
	}

	public int[][] getMapOne_2() {
		return mapOne_2;
	}

	public int[][] getMapOne_3() {
		return mapOne_3;
	}

	public int[][] getMapOne_4() {
		return mapOne_4;
	}

	public int[][] getMapOne_5() {
		return mapOne_5;
	}

	public int[][] getMapTwo_1() {
		return mapTwo_1;
	}

	public int[][] getMapTwo_2() {
		return mapTwo_2;
	}

	public int[][] getMapTwo_3() {
		return mapTwo_3;
	}

	public int[][] getMapTwo_4() {
		return mapTwo_4;
	}

	public int[][] getMapTwo_5() {
		return mapTwo_5;
	}

	public int[][] getMapThree_1() {
		return mapThree_1;
	}

	public int[][] getMapThree_2() {
		return mapThree_2;
	}

	public int[][] getMapThree_3() {
		return mapThree_3;
	}

	public int[][] getMapThree_4() {
		return mapThree_4;
	}

	public int[][] getMapThree_5() {
		return mapThree_5;
	}

	public void setMapOne_1(int[][] mapOne_1) {
		this.mapOne_1 = mapOne_1;
	}

	public void setMapOne_2(int[][] mapOne_2) {
		this.mapOne_2 = mapOne_2;
	}

	public void setMapOne_3(int[][] mapOne_3) {
		this.mapOne_3 = mapOne_3;
	}

	public void setMapOne_4(int[][] mapOne_4) {
		this.mapOne_4 = mapOne_4;
	}

	public void setMapOne_5(int[][] mapOne_5) {
		this.mapOne_5 = mapOne_5;
	}

	public void setMapTwo_1(int[][] mapTwo_1) {
		this.mapTwo_1 = mapTwo_1;
	}

	public void setMapTwo_2(int[][] mapTwo_2) {
		this.mapTwo_2 = mapTwo_2;
	}

	public void setMapTwo_3(int[][] mapTwo_3) {
		this.mapTwo_3 = mapTwo_3;
	}

	public void setMapTwo_4(int[][] mapTwo_4) {
		this.mapTwo_4 = mapTwo_4;
	}

	public void setMapTwo_5(int[][] mapTwo_5) {
		this.mapTwo_5 = mapTwo_5;
	}

	public void setMapThree_1(int[][] mapThree_1) {
		this.mapThree_1 = mapThree_1;
	}

	public void setMapThree_2(int[][] mapThree_2) {
		this.mapThree_2 = mapThree_2;
	}

	public void setMapThree_3(int[][] mapThree_3) {
		this.mapThree_3 = mapThree_3;
	}

	public void setMapThree_4(int[][] mapThree_4) {
		this.mapThree_4 = mapThree_4;
	}

	public void setMapThree_5(int[][] mapThree_5) {
		this.mapThree_5 = mapThree_5;
	}
}
